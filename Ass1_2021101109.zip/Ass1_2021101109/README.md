## Repository Link
https://github.com/viciousAegis/ISS_Assignments

## Question 1
The outputs for both parts are redirected to the terminal as well as output files `out1a.txt` and `out1b.txt`, as the output files are being used as input files for the questions `1b` and `2`.

## Question 3
This code uses the file `inp3.txt` as the input file to do all the operations on.

## Question 4
input format: comma seperated values
```
21,22,34,1,7,90,101,2,4,8,45 
```

## Question 5
input format:
```
<string>
```